package com.mk.wipower.download;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainPage extends Activity {
	private Button bttn_start, bttn_stop, bttn_pre, bttn_next;
	private TextView textV;
	private Intent intent;
	private Bundle bundle;
	private String[] arr = 
		{
			"http://www2.census.gov/census_2010/04-Summary_File_1/Alaska/ak2010.sf1.zip",  //35Mb,较慢
			"http://down.myapp.com/myapp/qqteam/AndroidQQ/mobileqq_android.apk", //22.8Mb, 较快
			"3.0 Mb",
			"http://gdown.baidu.com/data/wisegame/ea93eb209c1d5fe9/FunnyYoga_2.apk", // 3.0Mb
			"3.3 Mb",
			"http://bs.baidu.com/appstore/apk_259558DEB119E70487F456739AFCDCD7.apk", // 3.3 Mb
			"3.5 Mb, CCTV xinwen",
			"http://bs.baidu.com/appstore/apk_1125DFFCE9D1750A9381398627C10DDC.apk", // 
			"      ",
			"http://www.scilab.org/download/5.4.1/scilab-5.4.1.bin.linux-i686.tar.gz", // 163 Mb
			"http://down.m.duoku.com/game/50000/50550/20140812205747_DuoKu.apk", // 102 Mb
			"http://down.m.duoku.com/game/59000/59195/20140716194413_DuoKu.apk", // 55.8 Mb
			"http://imgskype.gmw.cn/software/SkypeSetupFull.exe", // 33.9 Mb
			"http://www.baidu.com/img/bdlogo.png"
		};
	private DoubleLinkedListStringUtil list = new DoubleLinkedListStringUtil("", arr);
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_page);
		
		bttn_start       = (Button)  findViewById(R.id.bttn_start)       ;
        bttn_stop        = (Button)  findViewById(R.id.bttn_stop)        ;
        bttn_pre         = (Button)  findViewById(R.id.bttn_pre)         ;
        bttn_next        = (Button)  findViewById(R.id.bttn_next)        ;
        
        textV = (TextView)findViewById(R.id.textV);
        
        intent = new Intent(MainPage.this, MyDownloadService.class);
		bundle = new Bundle();
		
		bundle.putInt("which", -10);
		intent.putExtras(bundle);
		MainPage.this.startService(intent);
        
		bttn_pre.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				MyDownloadService.url = list.getLast();
				textV.setText(MyDownloadService.url );
			}
		});
		
		bttn_next.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				MyDownloadService.url = list.getNext();
				textV.setText(MyDownloadService.url );
			}
		});
		
        bttn_start.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				bundle.putInt("which", 1);
				intent.putExtras(bundle);
				MainPage.this.startService(intent);
			}
		});
        
        bttn_stop.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				bundle.putInt("which", 2);
				intent.putExtras(bundle);
				MainPage.this.startService(intent);
				finish();
			}
		});
	}
	
	@Override
	public void onDestroy(){
		super.onDestroy();
	}
}
