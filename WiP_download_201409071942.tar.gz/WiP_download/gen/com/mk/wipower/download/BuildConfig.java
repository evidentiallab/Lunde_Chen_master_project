/** Automatically generated file. DO NOT MODIFY */
package com.mk.wipower.download;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}